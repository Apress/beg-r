CV <-
function(x) {
Coeff <- sd(x)/mean(x)
return(Coeff)
}
